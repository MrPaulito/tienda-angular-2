export class ProductoCarrito {
  id: number;
  descripcion : string;
  imagen: string;
  precio: number;
  cantidad: number;
}
