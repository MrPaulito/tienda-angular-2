export class Producto {
  id: number;
  nombre:string;
  descripcion : string;
  imagen: string;
  precio: number;
  disponible: number;
  informacion : string;
}
